# 6188086 Kittikorn Keeratikriengkrai
# 6188089 Nattawipa Saetae

## Assignment setup
### please check your library have OPENGL already
## Window
[![MinGW](https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcREEsFrL6Kv957dRSleOBm4qk7PISpJbImrbiDfmOC7K2vGCkER)](https://drive.google.com/open?id=147LGO_bCFHSqdZ6j1835qJb7XRS6-bZj)
### Download MinGW
[MinGW](https://drive.google.com/open?id=147LGO_bCFHSqdZ6j1835qJb7XRS6-bZj)

# How to use it ?
``` 
• Clone and Open In Vs Code 
• Create folder and set name like whatever you want
• Create file with .c extension
• Write Code
• Run bat file 
• the execute application is in executeFile(Folder)
• DONE!!
```

**Install and config**
* create Folder Compiler in C
* copy mingw into folder Complier and Rename it "mingw64"
* copy folder include in 
>  freeglut into "C:/Compiler/mingw64/x86_64-w64-mingw32"
* copy folder lib or lin/x64 into "
>  C:/Compiler/mingw64/x86_64-w64-mingw32/lib"
* copy freeglut.dll in freeglut/bin into 
> System32 
and 
> SysWOW64 
* open 
> filename.c 
* Run bat file 
* Done


# UsingBatFile
* please check the bat file is correct path or not but for this project I provide a correct path already.
```
.\RunOpenGL.bat
```
# The Output be like 
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image1.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image2.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image3.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image4.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image5.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image6.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image7.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image8.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image9.png "Front")
![alt text](https://github.com/china555/ITCS481_Computer-Graphics/blob/main/Assignment%202/Assets/Image10.png "Front")
